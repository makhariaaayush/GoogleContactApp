package com.example.project1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity2 extends AppCompatActivity {
    String name;
    String name1;
    View v;
    Intent intent = new Intent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText editText1 = (EditText) findViewById(R.id.editText1);
        editText1.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    name = editText1.getText().toString();
                    Log.i("MainActivity2","name is "+name);
                    name1=name.trim();
                    Log.i("MainActivity2","name is "+name.trim());
                    if (name1.matches("^[a-zA-Z ]*$")) {
                         if (name1.matches("[a-zA-Z]*")) {
                            intent.putExtra(name1, "Invalid Name");
                             intent.putExtra("Name of Contact being passed",name1);
                             Log.i("MainActivity2","Failing over here");
                             setResult(RESULT_CANCELED, intent);
                            finish();

                        } else {
                            intent.putExtra(name1, "Valid Name");
                             intent.putExtra("Name of Contact being passed",name1);
                             setResult(RESULT_OK, intent);
                            finish();

                        }
                    }
                    else {
                        intent.putExtra(name1, "Invalid Name");
                        intent.putExtra("Name of Contact being passed",name1);
                        setResult(RESULT_CANCELED, intent);

                        finish();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        setResult(RESULT_CANCELED, intent);
        finish();
    }

}











