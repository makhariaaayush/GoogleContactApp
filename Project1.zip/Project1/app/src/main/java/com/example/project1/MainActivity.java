package com.example.project1;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    Button button;
    Button button2;
    String a="";
    int r = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button2 = (Button) findViewById(R.id.button2);
        Button button = (Button) findViewById(R.id.button);
        button2.setOnClickListener(btn2listener);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });
    }


    public View.OnClickListener btn2listener = new View.OnClickListener()
    {
        @Override
        public void onClick(View v){
        if (r == -1) {
            Intent contactIntent = new Intent(ContactsContract.Intents.Insert.ACTION);
            contactIntent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            contactIntent.putExtra(ContactsContract.Intents.Insert.NAME, a);
            startActivity(contactIntent);
        } else {
            Toast.makeText(getApplicationContext(), "Invalid Name", Toast.LENGTH_SHORT).show();
        }
    }
    };



    public void openNewActivity() {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivityForResult(intent, 40);

    }

        protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        Button button2 = (Button) findViewById(R.id.button2);

            if (resultCode != 0) {
                a = intent.getStringExtra("Name of Contact being passed");
                r=-1;
        }
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (resultCode == RESULT_OK) {
                    Intent contactIntent = new Intent(ContactsContract.Intents.Insert.ACTION);
                    contactIntent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                    contactIntent.putExtra(ContactsContract.Intents.Insert.NAME, a);
                    startActivity(contactIntent);



                } else{
                    Toast.makeText(getApplicationContext(), "Invalid Name", Toast.LENGTH_SHORT).show();
                    r=0;
                }
            }
        });
    }
    @Override
    protected void onSaveInstanceState(Bundle A) {
        super.onSaveInstanceState(A);
        A.putString("Name",a);
        A.putInt("Result",r);
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
         a = savedInstanceState.getString("Name");
         r= savedInstanceState.getInt("Result");
        Log.i("value", a);

    }





}
